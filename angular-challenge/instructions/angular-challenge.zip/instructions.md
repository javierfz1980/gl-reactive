# Exercise Angular + RxJS:

## Instructions
- Install Angular CLI
- Bootstrap a new Angular app named "gl-challenge"
- Create a Service named PostsService
    - basePath https://jsonplaceholder.typicode.com
    - getPosts()                    ->  returns a list of all posts
    - getComment(postId)            ->  returns a list of comments for the postId
    - getPostWithComments(postId)   ->  returns a single post with comments
- Create 3 routes
    - /posts    -> Display a list of posts.
    - /post/id  -> Display a single post, with comments and a back button.
    - /         -> Redirect to /posts.
- Use Clarity framework for styling.
- Must use async pipe and RxJS, no manual subscriptions or Promises.
- Post title and body should be capitalized.
- Should display loading state using Clarity spinner + ng-container/ng-template.
- Consider using the best practices, checks, methodologies and patterns you would use for real world, client applications.

## Extra credit (optional)
- Testing

## Resources
- https://github.com/angular/angular-cli
- https://github.com/typicode/jsonplaceholder
- http://reactivex.io/rxjs/
- https://vmware.github.io/clarity

## Api Endpoints
- https://jsonplaceholder.typicode.com/posts
- https://jsonplaceholder.typicode.com/posts/1
- https://jsonplaceholder.typicode.com/comments/

## Thank you for your time!
If you have any questions related to this exercise please contact us by email, we'll be happy to help you.
- matias.alibertti@globallogic.com
- gerardo.leal@globallogic.com
- sebastian.dominguez@globallogic.com
